#ifndef __VERSION_H__
#define __VERSION_H__

#define _PLEORA_BUILD_
#define VERSION_COMPANY_NAME      "Pleora Technologies Inc.\0"
#define VERSION_LICENSING_STRING  "Pleora Technologies Inc.\0"
#define SOFTWARE_ROOT             "PUREGEV_ROOT"
#define PRODUCT_NAME              "eBUS SDK"
#define PRODUCT_NAME_MEDIUM       "eBUS SDK"
#define PRODUCT_NAME_SHORT        "eBUS_SDK"
#define VERSION_COPYRIGHT         "Copyright (c) 2002-2024\0"
#define VERSION_TRADEMARK         "\0"
#define VERSION_COMMENT           "\0"

#define VERSION_MAJOR             6
#define VERSION_MINOR             5
#define VERSION_SUB               1
#define VERSION_BUILD             6797

#define VERSION_STRING            "6, 5, 1, 6797\0"
#define NVERSION_STRING	  "6.5.1.6797\0"
#define VERSION_STRING_RESOURCE   ""

#endif // __VERSION_H__

