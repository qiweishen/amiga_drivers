var searchData=
[
  ['pvstream_5c_20gige_5c_20vision_5c_20parameters_3299',['PvStream\ GigE\ Vision\ Parameters',['../streamparametersgev.html',1,'']]],
  ['pvstream_5c_20usb3_5c_20vision_5c_20parameters_3300',['PvStream\ USB3\ Vision\ Parameters',['../streamparametersu3v.html',1,'']]]
];
