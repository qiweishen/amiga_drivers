#ifndef __LFT_VERSION_H__
#define __LFT_VERSION_H__

// *****************************************************************************"
//
//     Copyright (c) 2011, Pleora Technologies Inc., All rights reserved."
//
// *****************************************************************************"

// Automatically generated resources file"

#define LFT_MODULE_LONG_NAME "eBUS Universal Pro For Ethernet"
#define LFT_MODULE_NAME      "ebUniversalProForEthernet"
#define LFT_COMPANY          "Pleora Technologies Inc."
#define LFT_COPYRIGHT        "Copyright (c) 2002-2024"
#define LFT_VERSION          "7.5.1 build 6797"
#define LFT_VERSION_MAJOR    7
#define LFT_VERSION_MINOR    5
#define LFT_VERSION_SUB      1
#define LFT_VERSION_BUILD    6797

#endif /* __LFT_VERSION_H__ */

